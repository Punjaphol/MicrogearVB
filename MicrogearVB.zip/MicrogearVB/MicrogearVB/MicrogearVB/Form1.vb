﻿
'หมายเหตุ..Add reference ก่อนนะครัช..Add dll ที่ชื่อ  microgear.dll  แค่อันเดียวก็พอ
'แต่เวลาใช้งานต้องก๊อบ Dll เพื่อนๆมันไปด้วย คือ M2Mqtt.NetCf39.dll และ Newtonsoft.Json.dll และ RestSharp.dll
Imports io.netpie.microgear

Public Class Form1
    Dim netPIE As New Microgear

    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            netPIE.Disconnect()

        Catch ex As Exception

        End Try

        netPIE = Nothing

        End
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = ""

        netPIE.onMessage = AddressOf ONMessage

        netPIE.onAbsent = AddressOf ONAbsent
        netPIE.onPresent = AddressOf ONPresent
        netPIE.onConnect = AddressOf ONConnect
        netPIE.onInfo = AddressOf ONInfo
        netPIE.onError = AddressOf ONError
        netPIE.onDisconnect = AddressOf ONDisConnected

    End Sub

    Private Sub UpdateSTATUS(ByVal text As String)

        If TextBox1.InvokeRequired Then 'If we are on the wrong thread....
            TextBox1.Invoke(Sub() UpdateSTATUS(text)) 'marshal update back onto the UI thread that TextBox1 was created on, i.e. call the method again, but this time on the correct thread.
        Else
            TextBox1.Text = TextBox1.Text & text & vbCrLf
        End If

    End Sub

    Sub ONMessage(topic As String, message As String)
        Console.WriteLine(topic + " " + message)
        UpdateSTATUS(message)
    End Sub

    Sub ONConnect()

        Console.WriteLine("Now I'm connecting with NETPIE")
        Try
            netPIE.SetAlias("VB")

            netPIE.Subscribe("gearname/Topic1")
            netPIE.Subscribe("gearname/Topic2")


        Catch ex As Exception

        End Try


    End Sub

    Sub ONPresent(token As String)

        Console.WriteLine(token)

    End Sub

    Sub ONAbsent(token As String)

        Console.WriteLine(token)

    End Sub

    Sub ONError(strerror As String)

        Console.WriteLine(strerror)

    End Sub

    Sub ONInfo(info As String)

        Console.WriteLine(info)

    End Sub
    Sub ONDisConnected()

        Console.WriteLine("Connection ended")

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Try
            netPIE.Chat("Topic1", "555")
        Catch ex As Exception
            UpdateSTATUS(ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Try
            netPIE.Chat("Topic2", "123")
        Catch ex As Exception
            UpdateSTATUS(ex.Message)
        End Try

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Try

            netPIE.Connect("APPLICATION", "Key", "Secret")

            Button3.Enabled = False
            Button1.Enabled = True
            Button2.Enabled = True

        Catch ex As Exception
            UpdateSTATUS(ex.Message)
        End Try

    End Sub


  
End Class
